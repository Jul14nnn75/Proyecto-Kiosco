import tkinter as tk
from tkinter import messagebox
from turno3 import TurnoUI
from caja import CajaApp
from reporte import abrir_reportes  # ✅ Importamos el nuevo módulo de reportes


class SistemaKiosco(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Sistema de Kiosco - Menú Principal")
        self.state("zoomed")
        self.configure(bg="#0f5296")

        # Eliminamos toda la lógica de caja duplicada
        self.ventana_caja = None

        self.crear_interfaz()

    # =============================
    #  INTERFAZ PRINCIPAL
    # =============================
    def crear_interfaz(self):
        main_frame = tk.Frame(self, bg="#1e9fdb")
        main_frame.pack(expand=True, fill="both", padx=20, pady=20)

        titulo = tk.Label(main_frame, text="Sistema de Kiosco",
                          font=("Futura", 35, "bold"))
        titulo.pack(pady=30)

        botones_frame = tk.Frame(main_frame, bg="#0f5296")
        botones_frame.pack(expand=True)

        # ✅ ELIMINADO Configuración, AGREGADO Reportes
        botones = [
            ("💰 Gestión de Caja", self.abrir_caja, "#7916a0"),
            ("📦 Inventario", self.abrir_inventario, "#7916a0"),
            ("👥 Gestión de Turnos", self.abrir_turnos, "#2112f3"),
            ("📊 Reportes", self.abrir_reportes, "#2112f3"),  # ✅ NUEVO
            
        ]

        for i, (texto, comando, color) in enumerate(botones):
            btn = tk.Button(botones_frame, text=texto, command=comando,
                            font=("Arial", 14, "bold"),
                            bg=color, fg="white",
                            width=20, height=2,
                            relief="raised", bd=3)
            btn.grid(row=i // 2, column=i % 2, padx=10, pady=10, sticky="nsew")

        for c in range(2):
            botones_frame.columnconfigure(c, weight=1)
        for r in range(3):
            botones_frame.rowconfigure(r, weight=1)

        self.barra_estado = tk.Label(self, text="Sistema listo - © 2025 Kiosco System",
                                     relief="sunken", anchor="w",
                                     font=("Arial", 10), bg="#34495e", fg="white")
        self.barra_estado.pack(side="bottom", fill="x")

    # =============================
    #  GESTIÓN DE CAJA (USANDO caja.py)
    # =============================
    def abrir_caja(self):
        """Abre el sistema de caja unificado desde caja.py"""
        if self.ventana_caja and self.ventana_caja.winfo_exists():
            self.ventana_caja.lift()
            self.ventana_caja.focus_force()
            return

        # ✅ Usamos la CajaApp original que ya tiene toda la lógica
        self.ventana_caja = CajaApp()
        # Configuramos para que sea hija de la ventana principal
        self.ventana_caja.transient(self)
        self.ventana_caja.grab_set()
        
        # Centramos la ventana de caja relativa a la principal
        self.ventana_caja.geometry("+100+100")

    # =============================
    #  OTROS MÓDULOS
    # =============================
    def abrir_inventario(self):
        messagebox.showinfo("Inventario", "Módulo en desarrollo")

    def abrir_turnos(self):
        ventana_turnos = tk.Toplevel(self)
        ventana_turnos.title("Gestión de Turnos")
        ventana_turnos.geometry("800x600")
        ventana_turnos.transient(self)
        ventana_turnos.grab_set()
        ventana_turnos.focus_force()
        TurnoUI(master=ventana_turnos)

    def abrir_reportes(self):
        """Abre la ventana de reportes"""
        abrir_reportes(self)

    def salir_sistema(self):
        if messagebox.askyesno("Salir", "¿Está seguro que desea salir del sistema?"):
            # Cerramos también la ventana de caja si está abierta
            if self.ventana_caja and self.ventana_caja.winfo_exists():
                self.ventana_caja.destroy()
            self.destroy()


if __name__ == "__main__":
    app = SistemaKiosco()
    app.mainloop()