# Primero imports de terceros
import tkinter as tk
from tkinter import ttk, messagebox
import hashlib

# Luego imports locales
from database_config import DatabaseConfig
from backend_mysql import backend
from app_mysql import KioscoApp

def hash_pwd(pwd: str) -> str:
    return hashlib.sha256(pwd.encode("utf-8")).hexdigest()

def verificar_configuracion_mysql():
    """Verificar que MySQL esté configurado correctamente"""
    if not DatabaseConfig.test_connection():
        messagebox.showerror(
            "Error de Configuración", 
            "No se pudo conectar a MySQL.\n\n"
            "Por favor:\n"
            "1. Asegúrate de que MySQL esté instalado y funcionando\n"
            "2. Verifica la configuración en 'database_config.py'"
        )
        return False
    return True

def iniciar_aplicacion():
    # Verificar configuración de MySQL primero
    if not verificar_configuracion_mysql():
        return

    ventana = tk.Tk()
    ventana.config(bg="black")
    ventana.geometry("800x400")
    ventana.title("Login Kiosco - MySQL")
    ventana.resizable(False, False)

    # Centrar ventana
    ventana.eval('tk::PlaceWindow . center')

    usuario_var = tk.StringVar()
    contraseña_var = tk.StringVar()
    rol_var = tk.IntVar(value=1)

    def intentar_login():
        usuario = usuario_var.get().strip()
        contraseña = contraseña_var.get().strip()
        rol = "ADMIN" if rol_var.get() == 1 else "EMPLEADO"

        if not usuario or not contraseña:
            messagebox.showwarning("Atención", "Debe completar usuario y contraseña.")
            return

        try:
            usuario_info = backend.verificar_usuario(usuario, hash_pwd(contraseña), rol)
            
            if not usuario_info:
                messagebox.showerror("Error", "Credenciales incorrectas o rol no coincide.")
                return

            messagebox.showinfo("Éxito", f"Bienvenido {usuario_info['nombre_completo']} como {rol}")
            ventana.destroy()

            # Abrir aplicación principal
            root = tk.Tk()
            app = KioscoApp(root, usuario_info)
            root.mainloop()

        except Exception as e:
            messagebox.showerror("Error", f"Error de conexión: {e}")

    # Interfaz de login
    title_frame = tk.Frame(ventana, bg="black")
    title_frame.pack(pady=20)
    
    tk.Label(title_frame, text="🏪 KIOSCO APP - MySQL", 
             bg="black", fg="white", font=("Arial", 24, "bold")).pack()
    tk.Label(title_frame, text="Sistema de Punto de Venta con MySQL", 
             bg="black", fg="lightgray", font=("Arial", 12)).pack()

    form_frame = tk.Frame(ventana, bg="black")
    form_frame.pack(pady=20)

    # Campo usuario
    tk.Label(form_frame, text="Usuario:", bg="black", fg="white", 
             font=("Arial", 12)).grid(row=0, column=0, padx=10, pady=10, sticky="e")
    entry_user = tk.Entry(form_frame, textvariable=usuario_var, width=25, 
                         font=("Arial", 12))
    entry_user.grid(row=0, column=1, padx=10, pady=10)
    entry_user.focus()

    # Campo contraseña
    tk.Label(form_frame, text="Contraseña:", bg="black", fg="white", 
             font=("Arial", 12)).grid(row=1, column=0, padx=10, pady=10, sticky="e")
    entry_pass = tk.Entry(form_frame, textvariable=contraseña_var, show="*", 
                         width=25, font=("Arial", 12))
    entry_pass.grid(row=1, column=1, padx=10, pady=10)

    # Selección de rol
    tk.Label(form_frame, text="Rol:", bg="black", fg="white", 
             font=("Arial", 12)).grid(row=2, column=0, padx=10, pady=10, sticky="e")
    rol_frame = tk.Frame(form_frame, bg="black")
    rol_frame.grid(row=2, column=1, padx=10, pady=10, sticky="w")
    
    ttk.Radiobutton(rol_frame, text="Administrador", variable=rol_var, 
                   value=1).pack(side="left", padx=10)
    ttk.Radiobutton(rol_frame, text="Empleado", variable=rol_var, 
                   value=2).pack(side="left", padx=10)

    # Botón ingresar
    btn_frame = tk.Frame(ventana, bg="black")
    btn_frame.pack(pady=20)
    
    tk.Button(btn_frame, text="🔐 Ingresar", command=intentar_login, 
             bg="#4CAF50", fg="white", font=("Arial", 14, "bold"),
             width=15, height=2).pack()

    # Credenciales de demo
    demo_frame = tk.Frame(ventana, bg="black")
    demo_frame.pack(pady=10)
    
    demo_text = """Credenciales de Demo:
Admin: usuario 'admin', contraseña 'admin123'
Empleado: usuario 'empleado', contraseña 'empleado123'
Vendedor: usuario 'vendedor', contraseña 'vendedor123'"""
    
    tk.Label(demo_frame, text=demo_text, bg="black", fg="yellow", 
             font=("Arial", 10), justify="left").pack()

    # Información de base de datos
    db_frame = tk.Frame(ventana, bg="black")
    db_frame.pack(pady=5)
    
    db_info = f"Base de datos: {DatabaseConfig.DATABASE} @ {DatabaseConfig.HOST}"
    tk.Label(db_frame, text=db_info, bg="black", fg="#3498db", 
             font=("Arial", 9)).pack()

    # Atajos de teclado
    ventana.bind('<Return>', lambda e: intentar_login())
    ventana.bind('<Escape>', lambda e: ventana.quit())

    ventana.mainloop()

if __name__ == "__main__":
    iniciar_aplicacion()