# main.py
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from datetime import datetime

# Clases del sistema (las mismas que antes)
class DetalleVenta:
    def __init__(self, producto, cantidad, precio_unitario):
        self.producto = producto
        self.cantidad = cantidad
        self.precio_unitario = precio_unitario

    def subtotal(self):
        return self.cantidad * self.precio_unitario

    def __str__(self):
        return f"{self.producto} x{self.cantidad} - ${self.subtotal():.2f}"

class MetodoPago:
    def __init__(self, tipo, monto):
        self.tipo = tipo
        self.monto = monto

    def __str__(self):
        return f"Pago con {self.tipo}: ${self.monto:.2f}"

class Venta:
    def __init__(self, cliente):
        self.cliente = cliente
        self.fecha = datetime.now()
        self.detalles = []
        self.metodo_pago = None

    def agregar_detalle(self, detalle: DetalleVenta):
        self.detalles.append(detalle)

    def total(self):
        return sum(detalle.subtotal() for detalle in self.detalles)

    def registrar_pago(self, metodo_pago: MetodoPago):
        self.metodo_pago = metodo_pago

    def __str__(self):
        texto = f"🧾 Venta a {self.cliente} - {self.fecha.strftime('%d/%m/%Y %H:%M')}\n"
        for d in self.detalles:
            texto += f"  - {d}\n"
        texto += f"Total: ${self.total():.2f}\n"
        if self.metodo_pago:
            texto += f"{self.metodo_pago}\n"
        return texto

# Sistema de Caja
class CajaApp(tk.Toplevel):
    def __init__(self, parent, usuario_info):
        super().__init__(parent)
        self.title("Gestión de Caja")
        self.monto_apertura = None
        self.usuario_info = usuario_info

        ancho_ventana = 300
        alto_ventana = 550
        pantalla_alto = self.winfo_screenheight()
        y = (pantalla_alto - alto_ventana) // 2
        self.geometry(f"{ancho_ventana}x{alto_ventana}+0+{y - 150}")
        self.resizable(False,False)
        self.config(padx=20, pady=20)
        self.crear_botones()

    def crear_botones(self):
        titulo_frame = ttk.Frame(self)
        titulo_frame.pack(fill="x", pady=(0, 10))
        
        ttk.Label(titulo_frame, text=f"Caja - {self.usuario_info['nombre']}", 
                 font=("Arial", 10, "bold")).pack()
        ttk.Label(titulo_frame, text=f"Rol: {self.usuario_info['rol']}", 
                 font=("Arial", 8)).pack()

        botones = [
            ("💰 Facturar", self.accion_facturar),
            ("📂 Apertura", self.accion_apertura),
            ("💸 Retiro", self.accion_retiro),
            ("📋 Gastos", self.accion_gastos),
            ("💳 Ingreso", self.accion_ingreso),
            ("🔒 Cierre Caja", self.accion_cierre),
            ("🖨️ Imprimir", self.accion_impresora),
            ("🚪 Salir", self.accion_salir)
        ]

        for texto, comando in botones:
            boton = ttk.Button(self, text=texto, command=comando)
            boton.pack(fill="x", pady=5, ipady=8)

    def accion_facturar(self):
        if self.monto_apertura is None:
            messagebox.showerror("Error", "Para facturar la caja debe estar abierta.")
            return
        messagebox.showinfo("Facturación", "Caja abierta, listo para facturar.")

    def accion_apertura(self):
        if self.monto_apertura is not None:
            messagebox.showerror("Error", "La caja ya está abierta.")
            return

        popup = tk.Toplevel(self)
        popup.title("Apertura de Caja")
        popup.geometry("300x180")
        popup.transient(self)
        popup.grab_set()
        popup.configure(bg='white')

        x = (self.winfo_screenwidth() - 300) // 2
        y = (self.winfo_screenheight() - 180) // 2
        popup.geometry(f"+{x}+{y}")

        ttk.Label(popup, text="EFECTIVO INICIAL", font=("Arial", 10, "bold")).pack(pady=(15, 5))
        efectivo_entry = ttk.Entry(popup, font=("Arial", 12), justify="center")
        efectivo_entry.pack(pady=10, padx=20, fill="x")
        efectivo_entry.focus()

        def aceptar():
            texto = efectivo_entry.get().strip()
            texto = texto.replace(".", "").replace(",", ".")
            if not texto.replace(".", "", 1).isdigit():
                messagebox.showerror("Error", "Ingrese un monto válido.")
                return
            self.monto_apertura = float(texto)
            messagebox.showinfo("Éxito", f"Apertura registrada con ${self.monto_apertura:.2f}")
            popup.destroy()

        def cancelar():
            popup.destroy()

        frame_botones = ttk.Frame(popup)
        frame_botones.pack(pady=10)

        ttk.Button(frame_botones, text="Aceptar", command=aceptar).pack(side="left", padx=10)
        ttk.Button(frame_botones, text="Cancelar", command=cancelar).pack(side="left", padx=10)

    def accion_retiro(self):
        if self.monto_apertura is None:
            messagebox.showerror("Error", "La caja debe estar abierta para realizar un retiro.")
            return
        self._mostrar_popup_operacion("Retiro de Caja", "retiro")

    def accion_gastos(self):
        if self.monto_apertura is None:
            messagebox.showerror("Error", "La caja debe estar abierta para registrar un gasto")
            return
        self._mostrar_popup_operacion("Registrar Gasto", "gasto")

    def _mostrar_popup_operacion(self, titulo, tipo):
        popup = tk.Toplevel(self)
        popup.title(titulo)
        popup.geometry("350x250")
        popup.transient(self)
        popup.grab_set()
        popup.configure(bg='white')

        x = (self.winfo_screenwidth() - 350) // 2
        y = (self.winfo_screenheight() - 250) // 2
        popup.geometry(f"+{x}+{y}")

        monto_formateado = f"{self.monto_apertura:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
        saldo_label = ttk.Label(popup, text=f"Saldo disponible: ${monto_formateado}", 
                               font=("Arial", 10, "bold"))
        saldo_label.pack(pady=(15, 10))

        ttk.Label(popup, text=f"Motivo del {tipo}:").pack(anchor="w", padx=20)
        motivo_entry = ttk.Entry(popup, width=30)
        motivo_entry.pack(pady=5, padx=20, fill="x")

        ttk.Label(popup, text=f"Monto a {tipo}:").pack(anchor="w", padx=20)
        monto_entry = ttk.Entry(popup, width=30)
        monto_entry.pack(pady=5, padx=20, fill="x")
        monto_entry.focus()

        def aceptar():
            motivo = motivo_entry.get().strip()
            texto_monto = monto_entry.get().strip().replace(".", "").replace(",", ".")
            if not texto_monto.replace(".", "", 1).isdigit():
                messagebox.showerror("Error", "Ingrese un monto válido.")
                return

            monto_operacion = float(texto_monto)
            if monto_operacion > self.monto_apertura:
                messagebox.showerror("Error", "El monto excede el saldo disponible.")
                return

            if tipo == "retiro":
                self.monto_apertura -= monto_operacion
                messagebox.showinfo("Éxito", f"Retiro realizado: ${monto_operacion:.2f}\nMotivo: {motivo}")
            else:
                self.monto_apertura -= monto_operacion
                messagebox.showinfo("Éxito", f"Gasto registrado: ${monto_operacion:.2f}\nMotivo: {motivo}")
            
            popup.destroy()

        def cancelar():
            popup.destroy()

        frame_botones = ttk.Frame(popup)
        frame_botones.pack(pady=15)

        ttk.Button(frame_botones, text="Aceptar", command=aceptar).pack(side="left", padx=10)
        ttk.Button(frame_botones, text="Cancelar", command=cancelar).pack(side="left", padx=10)

    def accion_ingreso(self):
        if self.monto_apertura is None:
            messagebox.showerror("Error", "La caja debe estar abierta para realizar un ingreso.")
            return

        popup = tk.Toplevel(self)
        popup.title("Ingreso de Caja")
        popup.geometry("350x220")
        popup.transient(self)
        popup.grab_set()
        popup.configure(bg='white')

        x = (self.winfo_screenwidth() - 350) // 2
        y = (self.winfo_screenheight() - 220) // 2
        popup.geometry(f"+{x}+{y}")

        monto_formateado = f"{self.monto_apertura:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
        saldo_label = ttk.Label(popup, text=f"Saldo actual: ${monto_formateado}", 
                               font=("Arial", 10, "bold"))
        saldo_label.pack(pady=(15, 10))

        ttk.Label(popup, text="Motivo del ingreso:").pack(anchor="w", padx=20)
        motivo_entry = ttk.Entry(popup, width=30)
        motivo_entry.pack(pady=5, padx=20, fill="x")

        ttk.Label(popup, text="Monto a ingresar:").pack(anchor="w", padx=20)
        monto_entry = ttk.Entry(popup, width=30)
        monto_entry.pack(pady=5, padx=20, fill="x")
        monto_entry.focus()

        def aceptar():
            motivo = motivo_entry.get().strip()
            texto_monto = monto_entry.get().strip().replace(".", "").replace(",", ".")
            if not texto_monto.replace(".", "", 1).isdigit():
                messagebox.showerror("Error", "Ingrese un monto válido.")
                return
            monto_ingreso = float(texto_monto)
            self.monto_apertura += monto_ingreso
            messagebox.showinfo("Éxito", f"Ingreso realizado: ${monto_ingreso:.2f}\nMotivo: {motivo}")
            popup.destroy()

        def cancelar():
            popup.destroy()

        frame_botones = ttk.Frame(popup)
        frame_botones.pack(pady=15)

        ttk.Button(frame_botones, text="Aceptar", command=aceptar).pack(side="left", padx=10)
        ttk.Button(frame_botones, text="Cancelar", command=cancelar).pack(side="left", padx=10)

    def accion_cierre(self):
        if self.monto_apertura is None:
            messagebox.showerror("Error", "La caja ya está cerrada.")
            return

        ahora = datetime.now()
        fecha = ahora.strftime("%d/%m/%Y")
        hora = ahora.strftime("%H:%M:%S")

        monto_formateado = f"{self.monto_apertura:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")

        mensaje = (
            f"✅ Caja cerrada correctamente\n\n"
            f"📅 Fecha: {fecha}\n"
            f"⏰ Hora: {hora}\n"
            f"💰 Monto final: ${monto_formateado}\n"
            f"👤 Usuario: {self.usuario_info['nombre']}"
        )
        messagebox.showinfo("Cierre de Caja", mensaje)
        self.monto_apertura = None

    def accion_impresora(self):
        messagebox.showinfo("Impresora", "Función de impresión activada")

    def accion_salir(self):
        if self.monto_apertura is not None:
            respuesta = messagebox.askyesno("Caja Abierta", 
                                           "La caja aún está abierta. ¿Está seguro de que desea salir?")
            if not respuesta:
                return
        self.destroy()

# Sistema de Ventas (POS)
class SistemaVentas(tk.Toplevel):
    def __init__(self, parent, usuario_info):
        super().__init__(parent)
        self.title("Sistema de Ventas")
        self.geometry("1000x700")
        self.configure(bg="#f8f9fa")
        
        self.usuario_info = usuario_info
        self.venta = Venta("CONSUMIDOR FINAL")
        
        self.create_header()
        self.create_form()
        self.create_table()
        self.create_total_display()
        self.create_buttons()

        self.bind_all("<KeyPress-F1>", lambda e: self.registrar_venta())
        self.bind_all("<KeyPress-F3>", lambda e: self.modificar_cantidad())
        self.bind_all("<KeyPress-F4>", lambda e: self.agregar_producto())
        self.bind_all("<KeyPress-F5>", lambda e: self.borrar_producto())
        self.bind_all("<KeyPress-F7>", lambda e: self.registrar_pago("Efectivo"))
        self.bind_all("<KeyPress-F8>", lambda e: self.registrar_pago("Tarjeta"))
        self.bind_all("<KeyPress-F9>", lambda e: self.agregar_varios())
        self.bind_all("<KeyPress-F12>", lambda e: self.cerrar_sistema())

    def create_header(self):
        header_frame = tk.Frame(self, bg="#343a40", height=60)
        header_frame.pack(fill="x", side="top")
        header_frame.pack_propagate(False)
        
        tk.Label(header_frame, text="🏪 SISTEMA DE VENTAS", 
                bg="#343a40", fg="white", font=("Arial", 16, "bold")).pack(side="left", padx=20, pady=15)
        
        user_info = tk.Label(header_frame, 
                           text=f"Usuario: {self.usuario_info['nombre']} | Rol: {self.usuario_info['rol']}",
                           bg="#343a40", fg="#adb5bd", font=("Arial", 10))
        user_info.pack(side="right", padx=20, pady=15)

    def create_form(self):
        frame = tk.LabelFrame(self, text="📦 Datos del Producto", bg="#f8f9fa", 
                             font=("Arial", 10, "bold"), padx=15, pady=15)
        frame.pack(fill="x", padx=15, pady=10)

        tk.Label(frame, text="Producto:", bg="#f8f9fa", font=("Arial", 10)).grid(row=0, column=0, sticky="e", padx=5)
        self.producto_entry = tk.Entry(frame, width=25, font=("Arial", 10))
        self.producto_entry.grid(row=0, column=1, padx=5, pady=5, sticky="w")
        self.producto_entry.focus()

        tk.Label(frame, text="Cantidad:", bg="#f8f9fa", font=("Arial", 10)).grid(row=0, column=2, sticky="e", padx=5)
        self.cantidad_entry = tk.Entry(frame, width=10, font=("Arial", 10), justify="center")
        self.cantidad_entry.grid(row=0, column=3, padx=5, pady=5)
        self.cantidad_entry.insert(0, "1")

        tk.Label(frame, text="Precio:", bg="#f8f9fa", font=("Arial", 10)).grid(row=0, column=4, sticky="e", padx=5)
        self.precio_entry = tk.Entry(frame, width=12, font=("Arial", 10), justify="center")
        self.precio_entry.grid(row=0, column=5, padx=5, pady=5)
        self.precio_entry.insert(0, "0.00")

    def create_table(self):
        table_frame = tk.LabelFrame(self, text="🛒 Detalle de Venta", bg="#f8f9fa", 
                                   font=("Arial", 10, "bold"), padx=15, pady=15)
        table_frame.pack(fill="both", expand=True, padx=15, pady=10)

        columns = ("Código", "Descripción", "Cantidad", "Precio Unit.", "Total")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=12)
        
        column_widths = [150, 300, 100, 120, 120]
        for col, width in zip(columns, column_widths):
            self.tree.heading(col, text=col)
            self.tree.column(col, width=width, anchor="center")

        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

    def create_total_display(self):
        frame = tk.Frame(self, bg="#f8f9fa")
        frame.pack(fill="x", padx=15, pady=10)
        
        total_frame = tk.Frame(frame, bg="#28a745", relief="raised", bd=2)
        total_frame.pack(pady=5)
        
        tk.Label(total_frame, text="TOTAL A PAGAR:", font=("Arial", 14, "bold"), 
                bg="#28a745", fg="white").pack(side="left", padx=15, pady=8)
        self.total_label = tk.Label(total_frame, text="$ 0.00", font=("Arial", 24, "bold"), 
                                   fg="white", bg="#28a745")
        self.total_label.pack(side="left", padx=15, pady=8)

    def create_buttons(self):
        frame = tk.Frame(self, bg="#f8f9fa")
        frame.pack(fill="x", padx=15, pady=10)

        botones = [
            ("F1) ✅ Registrar", self.registrar_venta, "#28a745"),
            ("F3) 📊 Cantidad", self.modificar_cantidad, "#17a2b8"),
            ("F4) ➕ Agregar", self.agregar_producto, "#007bff"),
            ("F5) 🗑️ Borrar", self.borrar_producto, "#dc3545"),
            ("F7) 💵 Efectivo", lambda: self.registrar_pago("Efectivo"), "#20c997"),
            ("F8) 💳 Tarjeta", lambda: self.registrar_pago("Tarjeta"), "#6f42c1"),
            ("F9) 📦 Varios", self.agregar_varios, "#fd7e14"),
            ("F12) 🚪 Cerrar", self.cerrar_sistema, "#6c757d")
        ]

        for i, (text, cmd, color) in enumerate(botones):
            btn = tk.Button(frame, text=text, width=14, height=2, font=("Arial", 9, "bold"),
                          command=cmd, bg=color, fg="white", relief="raised", bd=2)
            btn.grid(row=0, column=i, padx=3, pady=5)

    def agregar_producto(self):
        producto = self.producto_entry.get().strip()
        if not producto:
            messagebox.showwarning("Error", "Debe ingresar un nombre de producto.")
            return

        try:
            cantidad = int(self.cantidad_entry.get())
            precio = float(self.precio_entry.get())
        except ValueError:
            messagebox.showerror("Error", "Cantidad y precio deben ser numéricos.")
            return

        detalle = DetalleVenta(producto, cantidad, precio)
        self.venta.agregar_detalle(detalle)

        self.tree.insert("", "end", values=(
            len(self.venta.detalles), 
            producto, 
            cantidad, 
            f"${precio:.2f}", 
            f"${detalle.subtotal():.2f}"
        ))
        self.actualizar_total()

        self.producto_entry.delete(0, tk.END)
        self.precio_entry.delete(0, tk.END)
        self.precio_entry.insert(0, "0.00")
        self.cantidad_entry.delete(0, tk.END)
        self.cantidad_entry.insert(0, "1")
        self.producto_entry.focus()

    def borrar_producto(self):
        selected = self.tree.selection()
        if selected:
            item = selected[0]
            index = self.tree.index(item)
            self.tree.delete(item)
            del self.venta.detalles[index]
        elif self.tree.get_children():
            item = self.tree.get_children()[-1]
            index = self.tree.index(item)
            self.tree.delete(item)
            del self.venta.detalles[index]
        else:
            messagebox.showinfo("Aviso", "No hay productos para borrar.")
            return

        self.actualizar_total()

    def modificar_cantidad(self):
        try:
            nueva_cantidad = simpledialog.askinteger("Cantidad", "Ingrese la cantidad para esta venta:", minvalue=1)
            if nueva_cantidad:
                self.cantidad_entry.delete(0, tk.END)
                self.cantidad_entry.insert(0, str(nueva_cantidad))
        except:
            messagebox.showerror("Error", "Cantidad inválida.")

    def actualizar_total(self):
        total = self.venta.total()
        self.total_label.config(text=f"$ {total:.2f}")

    def registrar_pago(self, tipo):
        if not self.venta.detalles:
            messagebox.showwarning("Error", "No hay productos en la venta.")
            return
            
        monto = self.venta.total()
        pago = MetodoPago(tipo, monto)
        self.venta.registrar_pago(pago)
        messagebox.showinfo("Pago registrado", str(pago))

    def agregar_varios(self):
        precio = simpledialog.askfloat("VARIOS", "Ingrese el precio para producto VARIOS:")
        if precio is None:
            return

        detalle = DetalleVenta("VARIOS", 1, precio)
        self.venta.agregar_detalle(detalle)
        self.tree.insert("", "end", values=(
            len(self.venta.detalles),
            "VARIOS", 
            1, 
            f"${precio:.2f}", 
            f"${precio:.2f}"
        ))
        self.actualizar_total()

    def registrar_venta(self):
        if not self.venta.detalles:
            messagebox.showwarning("Advertencia", "No hay productos para registrar.")
            return

        resumen = str(self.venta)
        messagebox.showinfo("Venta registrada", resumen)

        for item in self.tree.get_children():
            self.tree.delete(item)
        self.venta = Venta("CONSUMIDOR FINAL")
        self.actualizar_total()
        self.producto_entry.focus()

    def cerrar_sistema(self):
        confirmar = messagebox.askyesno("Cerrar sistema", "¿Desea cerrar el sistema de ventas?")
        if confirmar:
            self.destroy()

# Ventana de inicio de turno CORREGIDA
class InicioTurnoWindow(tk.Toplevel):
    def __init__(self, parent, usuario_info, callback):
        super().__init__(parent)
        self.title("Inicio de Turno - Empleado")
        self.geometry("450x400")
        self.configure(bg="#f8f9fa")
        self.usuario_info = usuario_info
        self.callback = callback
        self.parent = parent
        self.turno_iniciado = False
        
        self.transient(parent)
        self.grab_set()
        
        x = (parent.winfo_screenwidth() - 450) // 2
        y = (parent.winfo_screenheight() - 400) // 2
        self.geometry(f"+{x}+{y}")
        
        self.protocol("WM_DELETE_WINDOW", self.cerrar_ventana)
        self.crear_interfaz()
        
    def crear_interfaz(self):
        main_frame = tk.Frame(self, bg="#f8f9fa", padx=30, pady=30)
        main_frame.pack(fill="both", expand=True)
        
        tk.Label(main_frame, text="🕒", font=("Arial", 48), bg="#f8f9fa").pack(pady=(0, 10))
        tk.Label(main_frame, text="INICIO DE TURNO", font=("Arial", 16, "bold"), 
                bg="#f8f9fa").pack(pady=(0, 5))
        
        info_frame = tk.Frame(main_frame, bg="#e9ecef", relief="solid", bd=1)
        info_frame.pack(fill="x", pady=15, padx=10)
        
        tk.Label(info_frame, text=f"Empleado: {self.usuario_info['nombre']}", 
                font=("Arial", 12, "bold"), bg="#e9ecef").pack(pady=8)
        tk.Label(info_frame, text=f"Turno: {datetime.now().strftime('%d/%m/%Y %H:%M')}", 
                font=("Arial", 10), bg="#e9ecef").pack(pady=5)
        
        # Campos para datos del turno
        tk.Label(main_frame, text="Hora de Inicio:", font=("Arial", 10), 
                bg="#f8f9fa").pack(anchor="w", pady=(15, 5))
        
        self.hora_inicio_entry = tk.Entry(main_frame, font=("Arial", 12), 
                                        width=20, justify="center")
        self.hora_inicio_entry.pack(pady=5, fill="x")
        self.hora_inicio_entry.insert(0, datetime.now().strftime("%H:%M"))
        
        tk.Label(main_frame, text="Hora de Fin:", font=("Arial", 10), 
                bg="#f8f9fa").pack(anchor="w", pady=(10, 5))
        
        self.hora_fin_entry = tk.Entry(main_frame, font=("Arial", 12), 
                                     width=20, justify="center")
        self.hora_fin_entry.pack(pady=5, fill="x")
        self.hora_fin_entry.insert(0, "18:00")
        
        tk.Label(main_frame, text="Monto Inicial de Caja:", font=("Arial", 10), 
                bg="#f8f9fa").pack(anchor="w", pady=(10, 5))
        
        self.monto_inicial_entry = tk.Entry(main_frame, font=("Arial", 12), 
                                          width=20, justify="center")
        self.monto_inicial_entry.pack(pady=5, fill="x")
        self.monto_inicial_entry.insert(0, "0.00")
        
        btn_frame = tk.Frame(main_frame, bg="#f8f9fa")
        btn_frame.pack(pady=20)
        
        tk.Button(btn_frame, text="✅ Iniciar Turno", command=self.iniciar_turno,
                 bg="#28a745", fg="white", font=("Arial", 11, "bold"),
                 width=15, height=2).pack(side="left", padx=10)
                 
        tk.Button(btn_frame, text="❌ Cancelar", command=self.cancelar,
                 bg="#dc3545", fg="white", font=("Arial", 11),
                 width=12, height=2).pack(side="left", padx=10)
    
    def iniciar_turno(self):
        hora_inicio = self.hora_inicio_entry.get().strip()
        hora_fin = self.hora_fin_entry.get().strip()
        monto_inicial = self.monto_inicial_entry.get().strip()
        
        if not all([hora_inicio, hora_fin, monto_inicial]):
            messagebox.showerror("Error", "Complete todos los campos del turno")
            return
            
        try:
            monto = float(monto_inicial.replace(",", "."))
        except ValueError:
            messagebox.showerror("Error", "Monto inicial debe ser un número válido")
            return
        
        self.turno_iniciado = True
        messagebox.showinfo("Éxito", 
                          f"Turno iniciado para {self.usuario_info['nombre']}\n"
                          f"Hora inicio: {hora_inicio}\n"
                          f"Hora fin: {hora_fin}\n"
                          f"Monto inicial: ${monto:.2f}")
        self.destroy()
        # CORREGIDO: Llamar al callback correctamente
        self.callback(self.usuario_info)
    
    def cancelar(self):
        if messagebox.askyesno("Confirmar", "¿Desea cancelar el inicio de turno?\n\nSe cerrará la sesión."):
            self.cerrar_ventana()
    
    def cerrar_ventana(self):
        self.destroy()
        self.parent.deiconify()

# Sistema de Login CORREGIDO
class LoginSystem:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Sistema de Kiosco - Login")
        self.root.geometry("500x450")
        self.root.configure(bg="#1a1a1a")
        self.root.resizable(False, False)
        
        self.root.eval('tk::PlaceWindow . center')
        
        self.usuarios = {
            "admin": {"password": "admin", "nombre": "Administrador", "rol": "ADMIN"},
            "empleado": {"password": "empleado", "nombre": "Empleado General", "rol": "EMPLEADO"},
            "vendedor": {"password": "vendedor", "nombre": "Vendedor", "rol": "EMPLEADO"}
        }
        
        self.crear_interfaz_login()
    
    def crear_interfaz_login(self):
        main_frame = tk.Frame(self.root, bg="#2c3e50", padx=30, pady=30)
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        title_frame = tk.Frame(main_frame, bg="#2c3e50")
        title_frame.pack(pady=(0, 30))
        
        tk.Label(title_frame, text="🏪 KIOSCO APP", 
                font=("Arial", 24, "bold"), bg="#2c3e50", fg="#ecf0f1").pack()
        tk.Label(title_frame, text="Sistema de Gestión Comercial", 
                font=("Arial", 12), bg="#2c3e50", fg="#bdc3c7").pack(pady=(5, 0))
        
        form_frame = tk.Frame(main_frame, bg="#2c3e50")
        form_frame.pack(pady=20, fill="x")
        
        tk.Label(form_frame, text="Usuario:", font=("Arial", 11, "bold"), 
                bg="#2c3e50", fg="#ecf0f1").grid(row=0, column=0, sticky="w", pady=8)
        self.usuario_entry = tk.Entry(form_frame, font=("Arial", 12), width=25)
        self.usuario_entry.grid(row=0, column=1, padx=10, pady=8, sticky="ew")
        self.usuario_entry.focus()
        
        tk.Label(form_frame, text="Contraseña:", font=("Arial", 11, "bold"), 
                bg="#2c3e50", fg="#ecf0f1").grid(row=1, column=0, sticky="w", pady=8)
        self.password_entry = tk.Entry(form_frame, font=("Arial", 12), show="•", width=25)
        self.password_entry.grid(row=1, column=1, padx=10, pady=8, sticky="ew")
        
        tk.Label(form_frame, text="Rol:", font=("Arial", 11, "bold"), 
                bg="#2c3e50", fg="#ecf0f1").grid(row=2, column=0, sticky="w", pady=8)
        
        self.rol_var = tk.StringVar(value="ADMIN")
        rol_frame = tk.Frame(form_frame, bg="#2c3e50")
        rol_frame.grid(row=2, column=1, padx=10, pady=8, sticky="w")
        
        tk.Radiobutton(rol_frame, text="Administrador", variable=self.rol_var, 
                      value="ADMIN", bg="#2c3e50", fg="#ecf0f1", 
                      selectcolor="#34495e", font=("Arial", 10)).pack(side="left", padx=10)
        tk.Radiobutton(rol_frame, text="Empleado", variable=self.rol_var, 
                      value="EMPLEADO", bg="#2c3e50", fg="#ecf0f1",
                      selectcolor="#34495e", font=("Arial", 10)).pack(side="left", padx=10)
        
        login_btn = tk.Button(main_frame, text="🔐 INGRESAR AL SISTEMA", 
                            font=("Arial", 12, "bold"), bg="#e74c3c", fg="white",
                            command=self.verificar_login, width=25, height=2)
        login_btn.pack(pady=20)
        
        demo_frame = tk.Frame(main_frame, bg="#34495e", relief="solid", bd=1)
        demo_frame.pack(fill="x", pady=10)
        
        demo_text = """Credenciales de Demo:
• Admin: usuario 'admin', contraseña 'admin'
• Empleado: usuario 'empleado', contraseña 'empleado' 
• Vendedor: usuario 'vendedor', contraseña 'vendedor'"""
        
        tk.Label(demo_frame, text=demo_text, bg="#34495e", fg="#bdc3c7",
                font=("Arial", 9), justify="left").pack(padx=10, pady=8)
        
        self.root.bind('<Return>', lambda e: self.verificar_login())
        self.root.bind('<Escape>', lambda e: self.root.destroy())
    
    def verificar_login(self):
        usuario = self.usuario_entry.get().strip()
        password = self.password_entry.get().strip()
        rol_seleccionado = self.rol_var.get()
        
        if not usuario or not password:
            messagebox.showerror("Error", "Por favor complete todos los campos")
            return
        
        if usuario in self.usuarios:
            usuario_info = self.usuarios[usuario]
            if password == usuario_info["password"] and rol_seleccionado == usuario_info["rol"]:
                messagebox.showinfo("Éxito", f"Bienvenido {usuario_info['nombre']}!")
                self.root.withdraw()
                self.abrir_sistema_principal(usuario_info)
            else:
                messagebox.showerror("Error", "Credenciales incorrectas o rol no coincide")
        else:
            messagebox.showerror("Error", "Usuario no encontrado")
    
    def abrir_sistema_principal(self, usuario_info):
        if usuario_info["rol"] == "EMPLEADO":
            # CORREGIDO: Pasar self.iniciar_kiosco_app como callback
            InicioTurnoWindow(self.root, usuario_info, self.iniciar_kiosco_app)
        else:
            # Para admin, ir directamente al sistema principal
            self.iniciar_kiosco_app(usuario_info)
    
    def iniciar_kiosco_app(self, usuario_info):
        kiosco_root = tk.Toplevel(self.root)
        kiosco_root.title(f"KioscoApp - {usuario_info['nombre']} ({usuario_info['rol']})")
        kiosco_root.geometry("600x400")
        kiosco_root.configure(bg="#2c3e50")
        
        header = tk.Frame(kiosco_root, bg="#34495e", height=80)
        header.pack(fill="x", side="top")
        header.pack_propagate(False)
        
        tk.Label(header, text="🏪 KIOSCO APP", font=("Arial", 20, "bold"), 
                bg="#34495e", fg="white").pack(side="left", padx=20, pady=20)
        
        user_label = tk.Label(header, 
                            text=f"Usuario: {usuario_info['nombre']} | Rol: {usuario_info['rol']}",
                            font=("Arial", 12), bg="#34495e", fg="#bdc3c7")
        user_label.pack(side="right", padx=20, pady=20)
        
        main_frame = tk.Frame(kiosco_root, bg="#2c3e50", padx=30, pady=30)
        main_frame.pack(fill="both", expand=True)
        
        tk.Label(main_frame, text="SELECCIONE UN MÓDULO", 
                font=("Arial", 16, "bold"), bg="#2c3e50", fg="#ecf0f1").pack(pady=(0, 30))
        
        modulos_frame = tk.Frame(main_frame, bg="#2c3e50")
        modulos_frame.pack(pady=20)
        
        # Solo dos módulos: Sistema de Ventas y Gestión de Caja
        botones = [
            ("💼 Sistema de Ventas", lambda: SistemaVentas(kiosco_root, usuario_info), "#e74c3c"),
            ("💰 Gestión de Caja", lambda: CajaApp(kiosco_root, usuario_info), "#27ae60")
        ]
        
        # Si es empleado, solo mostrar Sistema de Ventas
        if usuario_info["rol"] == "EMPLEADO":
            btn = tk.Button(modulos_frame, text=botones[0][0], font=("Arial", 14, "bold"),
                          bg=botones[0][2], fg="white", width=25, height=3,
                          command=botones[0][1], relief="raised", bd=3)
            btn.pack(pady=20)
        else:
            # Si es admin, mostrar ambos módulos
            for i, (texto, comando, color) in enumerate(botones):
                btn = tk.Button(modulos_frame, text=texto, font=("Arial", 12, "bold"),
                              bg=color, fg="white", width=20, height=2,
                              command=comando, relief="raised", bd=3)
                btn.grid(row=0, column=i, padx=20, pady=10)
        
        tk.Button(main_frame, text="🚪 Cerrar Sesión", 
                 font=("Arial", 11, "bold"), bg="#7f8c8d", fg="white",
                 command=lambda: self.cerrar_sesion(kiosco_root), 
                 width=20, height=1).pack(pady=20)
        
        kiosco_root.protocol("WM_DELETE_WINDOW", lambda: self.cerrar_sesion(kiosco_root))
    
    def cerrar_sesion(self, kiosco_window):
        kiosco_window.destroy()
        self.root.deiconify()
        self.usuario_entry.delete(0, tk.END)
        self.password_entry.delete(0, tk.END)
        self.usuario_entry.focus()
    
    def run(self):
        self.root.mainloop()

# Ejecutar la aplicación
if __name__ == "__main__":
    app = LoginSystem()
    app.run()
